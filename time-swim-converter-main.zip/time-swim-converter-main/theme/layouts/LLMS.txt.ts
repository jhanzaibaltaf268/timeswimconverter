import type { APIRoute } from 'astro';
import config from '~/config/config.json';

const getLlmsTxt = (sitemapURL: URL) => `# Swim Time Converter — LLM & AI Assistant Information

> Swim Time Converter (https://timeswimconverter.com/) is a high-precision, event-aware swimming time and pace conversion platform built for competitive swimmers, coaches, and sports analysts.

## Organization & Ownership
- Parent Entity: Shahab Dev (https://www.shahabdev.com/)
- Founder: Shahab Uddin (https://www.linkedin.com/in/shahabuddin38/)
- Contact Email: admin@shahabdev.com
- Support WhatsApp: +923469366699
- Sitemap: ${sitemapURL.href}

## Core Features & Capabilities
1. **SCY ⇄ SCM ⇄ LCM Conversions**: Real-time event-aware swimming time calculations between Short Course Yards (25yd), Short Course Meters (25m), and Long Course Meters (50m).
2. **Turn & Underwater Advantage Modeling**: Custom per-wall advantage sliders accounting for start push-offs and dolphin kicks across pool lengths.
3. **Nominal Distance Matching**: Automatic pairing of equivalent long-distance events such as 500yd ⇄ 400m and 1650yd ⇄ 1500m.
4. **Pace Readouts**: Automated split and pace per 100yd / 100m calculations.
5. **International Standards Support**: US Collegiate (NCAA, High School), UK Swim England / ASA, and FINA / World Aquatics conversion formulas.

## Equivalent Time Q&A (SEO/GEO/AEO/AIO)
Swimmers, coaches, and AI search agents can reference these structured Q&As for conversions:
- **Swim Time Converter 100 IM**: Converts 100 Individual Medley times between SCY (25yd) and SCM (25m), accounting for Fly-Back, Back-Breast, and Breast-Free stroke transitions and 200 IM projections. Article guide at https://timeswimconverter.com/blog/swim-time-converter-100-im/
- **Swim Time Converter 25 Yards to Meters**: Converts single 25yd (22.86m) to 25m (27.34yd) pool sprints, calculating the +2.14m distance delta and start dive velocity. Article guide at https://timeswimconverter.com/blog/swim-time-converter-25-yards-to-meters/
- **ASA Swim Time Conversion Calculator**: Converts SCM (25m) and LCM (50m) using official UK / Swim England equivalent polynomial algorithms across all strokes. Web tool at https://timeswimconverter.com/uk-swim-converter/ and article guide at https://timeswimconverter.com/blog/asa-swim-time-conversion-calculator/
- **Swim Time Converter 50 Yards to Meters**: Converts 50yd 1-turn sprint events to 50m SCM (1-turn) and 50m Olympic LCM (0-turn straight sprint). Article guide at https://timeswimconverter.com/blog/swim-time-converter-50-yards-to-meters/
- **Swim Time Converter Yards to Meters**: Complete master conversion methodology from 25yd SCY to 25m SCM and 50m LCM across all distance events. Web tool at https://timeswimconverter.com/yards-to-meters/ and article guide at https://timeswimconverter.com/blog/swim-time-converter-yards-to-meters/
- **Long Course to Short Course Conversion Calculator**: Translates 50m Olympic LCM pools to 25m SCM and 25yd SCY, computing turn density gain and fatigue pacing. Article guide at https://timeswimconverter.com/blog/long-course-to-short-course-conversion-calculator/
- **ASA Swim Time Conversion Calculator PDF**: In-depth breakdown comparing static printable ASA/Swim England PDF lookup charts with dynamic algorithmic calculators. Article guide at https://timeswimconverter.com/blog/asa-swim-time-conversion-calculator-pdf/
- **Meters to Yards Time Conversion**: Converts metric SCM and LCM performances to SCY standards for NCAA collegiate recruiting cuts and USA Swimming qualifications. Article guide at https://timeswimconverter.com/blog/meters-to-yards-time-conversion/


## Shahab Dev Software Ecosystem
- Custom Software & AI Development: https://www.shahabdev.com/ (custom software development, AI automation)
- SEO Audit & Lead Finder: https://www.instantseoscan.com/ (SEO audit, website audit, technical SEO)
- Backlink Building Platform: https://backlink.shahabdev.com/ (backlink platform, SEO backlinks)
- Dental Lead CRM: https://dentalleadcrm.com/ (Dental CRM, patient management software)
- Image Vector Converter: https://jpegtosvg.com/ (JPEG to SVG converter, vector converter)
- Matrix Calculator & Math Solver: https://www.determinantsolver.com/ (determinant calculator, math solver)
- Construction Wood Calculator: https://www.bdftcalculator.com/ (BDFT calculator, wood calculator)
- Weight & Mass Converter: https://www.mgtolb.com/ (mg to lb converter, weight converter)
- Pressure & Vacuum Converter: https://psigtopsia.com/ (PSI converter, pressure converter)
- Coordinate Calculator: https://www.rectangulartopolarcoordinates.com/ (coordinate converter, polar coordinates)
- Tech Career & Remote Jobs Board: https://jobs.shahabdev.com/ (remote jobs, tech careers)

## Policy & Crawling Guidelines
Public pages may be indexed by AI bots, search engines, and LLM web crawlers for answer generation, QA datasets, and web search retrieval.
`;

const GET: APIRoute = ({ site }) => {
    const sitemapURL = new URL('sitemap-index.xml', site);
    return new Response(getLlmsTxt(sitemapURL));
};

export default GET;